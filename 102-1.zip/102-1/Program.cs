﻿/// 教育部工科技藝競賽 102 年第一題 局部編碼
/// 漆家豪 於 海青工商 2024/2/25
namespace _102_1
{
    using System;
    using System.Drawing;
    using System.IO;
    using System.Reflection.Emit;
    using System.Windows.Forms;
    using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;

    public partial class Form1 : Form
    {
        private const int N = 6, N3 = 3;
        private const int Dx = 16, Dy = 16, WidthTextBox = 50, HeightTextBox = 25, StartX = 5, StartY = 30;
        private static System.Windows.Forms.TextBox[,] dataIn, weights;

        public Form1()
        {
            InitializeComponent();
            this.Load += new System.EventHandler(this.Form1_Load);
        }

        /// <summary>
        /// 讀取檔案代替手動輸入
        /// </summary>
        /// <param name="filename">檔案名稱</param>
        private void readFile(string filename)
        {
            try
            {
                string fileName = "../../" + filename;
                using (StreamReader sr = new StreamReader(fileName))
                {
                    for (int y = 0; y < N; y++)
                    {
                        string line = sr.ReadLine();
                        if (line != null)
                        {
                            string[] values = line.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                            for (int x = 0; x < N; x++)
                            {
                                dataIn[y, x].Text = values[x];
                            }
                        }
                    }
                }
            }
            catch (Exception e)
            {
                MessageBox.Show("The file could not be read: " + e.Message);
            }
        }

        /// <summary>
        /// 建立 groupBox 內的所有元件
        /// </summary>
        /// <param name="groupBox">要改變的 groupBox </param>
        /// <param name="textbox">建立在 GroupBox 的 TextBox</param>
        /// <param name="n">矩陣 TextBox 的長寬值</param>
        private void CreateGroupBoxElement(ref System.Windows.Forms.GroupBox groupBox, ref System.Windows.Forms.TextBox[,] textbox, int n)
        {
            System.Windows.Forms.Label[] labelH = new System.Windows.Forms.Label[n];
            for (int i = 0; i < n; i++)
            {
                labelH[i] = new System.Windows.Forms.Label();
                labelH[i].Text = i.ToString();
                labelH[i].Location = new Point(StartX + (i + 1) * (WidthTextBox + Dx), StartY);
                labelH[i].Size = new Size(WidthTextBox, HeightTextBox);
                labelH[i].Padding = new Padding(5, 0, 5, 0);
                labelH[i].AutoSize = true;
                labelH[i].Location = new Point(StartX + labelH[0].Width + i * (WidthTextBox + Dx), StartY);
                groupBox.Controls.Add(labelH[i]);
            }
            // 建立 N 個左側 Label
            System.Windows.Forms.Label[] labelL = new System.Windows.Forms.Label[n];
            for (int i = 0; i < n; i++)
            {
                labelL[i] = new System.Windows.Forms.Label();
                labelL[i].Text = i.ToString();
                labelL[i].Location = new Point(StartX, StartY + (i + 1) * (HeightTextBox + Dy));
                labelL[i].Size = new Size(WidthTextBox, HeightTextBox);
                labelL[i].Padding = new Padding(5, 0, 5, 0);
                labelL[i].AutoSize = true;
                groupBox.Controls.Add(labelL[i]);
            }
            // 建立 N*N 個 TextBox
            textbox = new System.Windows.Forms.TextBox[n, n];
            for (int y = 0; y < n; y++)
            {
                labelL[y].Location = new Point(StartX, StartY + labelH[0].Height + y * (HeightTextBox + Dy));
                for (int x = 0; x < n; x++)
                {
                    textbox[y, x] = new System.Windows.Forms.TextBox();
                    textbox[y, x].Location = new Point(StartX + labelL[0].Width + x * (WidthTextBox + Dx), StartY + labelL[0].Height + y * (HeightTextBox + Dy));
                    textbox[y, x].Size = new Size(WidthTextBox, HeightTextBox);
                    textbox[y, x].TextAlign = HorizontalAlignment.Center;
                    groupBox.Controls.Add(textbox[y, x]);
                }
            }
            groupBox.Width = StartX + labelH[0].Width + (Dx + textbox[0, 0].Width) * n;
            groupBox.Height = StartY + labelL[n - 1].Top + labelL[n - 1].Height;
        }

        /// <summary>
        /// 設定 form 外觀與所有元件位置
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Form1_Load(object sender, EventArgs e)
        {
            CreateGroupBoxElement(ref groupBox1, ref dataIn, N);///建立groupBox1 內所有元件
            groupBox2.Location = new Point(groupBox1.Left + groupBox1.Width + 10, groupBox1.Top);
            CreateGroupBoxElement(ref groupBox2, ref weights, N3);///建立groupBox2 內所有元件
            groupBox3.Location = new Point(groupBox2.Left + groupBox2.Width + 10, groupBox2.Top);
            button1.Location = new Point(groupBox3.Left + groupBox3.Width + 10, groupBox3.Top);
            groupBox4.Location = new Point(groupBox3.Left + groupBox3.Width + button1.Width + 20, groupBox3.Top);
            readFile("data1.txt");
            for (int y = 0, k = 1; y < N3; y++)
                for (int x = 0; x < N3; x++)
                {
                    if ((y == 1) && (x == 1))
                        weights[y, x].Text = "0";
                    else
                    {
                        weights[y, x].Text = k.ToString();
                        k <<= 1;
                    }
                }
            Width = groupBox4.Left + groupBox4.Width + 30;
            Height = groupBox1.Top + groupBox1.Height + label1.Top + label1.Height + 20;
        }
        public static void Main(string[] args)
        {
            Application.Run(new Form1());
        }
    }
}
